#!/bin/sh
./sing-box run -c config.json